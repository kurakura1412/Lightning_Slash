(function () {
    'use strict';
    
    document.getElementsByTagName('body')[0].style.width = window.innerWidth + 'px';
}());